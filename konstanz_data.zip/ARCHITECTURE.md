# Архитектура приложения: Констанц Open Data Explorer

## 📚 Учебное руководство по коду

Этот документ объясняет, как работает приложение, как код организован и как данные обрабатываются.

---

## 🏗️ Общая архитектура

Приложение состоит из двух основных компонентов:

1. **`app.py`** - Streamlit-приложение (пользовательский интерфейс)
2. **`src/visualizer.py`** - Модуль визуализации (бизнес-логика)

```
┌─────────────────┐
│   app.py        │  ← Пользовательский интерфейс (Streamlit)
│                 │
│  - Загрузка UI  │
│  - Загрузка данных│
│  - Отображение  │
└────────┬────────┘
         │
         │ вызывает
         ▼
┌─────────────────┐
│ visualizer.py   │  ← Логика визуализации
│                 │
│  - Обработка данных│
│  - Создание графиков│
└─────────────────┘
```

---

## 📄 Часть 1: app.py - Пользовательский интерфейс

### Импорты и настройка (строки 1-21)

```python
import streamlit as st
import pandas as pd
from pathlib import Path
import sys

# Добавляем src в путь Python, чтобы можно было импортировать модули
sys.path.append(str(Path(__file__).parent))

from src.visualizer import DataVisualizer
```

**Что происходит:**
- `streamlit` - библиотека для создания веб-приложений
- `pandas` - для работы с данными (DataFrame)
- `Path` - для работы с путями к файлам
- `sys.path.append()` - добавляет текущую директорию в путь Python, чтобы можно было импортировать модули из `src/`
- `DataVisualizer` - наш класс для создания графиков

### Конфигурация страницы (строки 17-21)

```python
st.set_page_config(
    page_title="Konstanz Open Data Explorer",
    page_icon="📊",
    layout="wide"
)
```

**Что происходит:**
- Настраивает заголовок страницы в браузере
- Устанавливает иконку
- `layout="wide"` - использует всю ширину экрана

### Заголовок и Sidebar (строки 24-67)

```python
st.title("📊 Konstanz Open Data Explorer")
st.markdown("**Prototyp eines Werkzeugs...**")

with st.sidebar:
    st.title("Konstanz Open Data Explorer")
    # ... информация о данных, контакты и т.д.
```

**Что происходит:**
- `st.title()` - создает большой заголовок
- `st.markdown()` - позволяет использовать Markdown-разметку
- `st.sidebar` - создает боковую панель (видна на десктопе, скрыта в меню на мобильных)

### Session State - Хранение данных между перезагрузками (строки 69-73)

```python
if 'current_data' not in st.session_state:
    st.session_state.current_data = None
if 'current_file' not in st.session_state:
    st.session_state.current_file = None
```

**Что происходит:**
- `st.session_state` - это словарь, который сохраняет данные между перезагрузками страницы
- `current_data` - хранит загруженный DataFrame
- `current_file` - хранит имя текущего файла
- Проверка `if 'key' not in ...` нужна, чтобы не перезаписать данные при повторном запуске скрипта

**Почему это важно:**
- Streamlit перезапускает скрипт при каждом взаимодействии пользователя
- Без `session_state` данные терялись бы при каждом клике
- С `session_state` данные сохраняются в течение сессии

### Автоматическая загрузка данных (строки 75-84)

```python
if st.session_state.current_data is None:
    migration_file = Path("data/raw/Aussenwanderung_nach_Herkunfts_Ziel-Staat_2010-2023_0_0.csv")
    if migration_file.exists():
        try:
            df = pd.read_csv(migration_file, sep=';', encoding='utf-8')
            st.session_state.current_data = df
            st.session_state.current_file = migration_file.name
        except:
            pass
```

**🔍 Ключевой вопрос: Зачем session_state, если данные из CSV?**

**Ответ:** Да, данные берутся из CSV, но читать CSV каждый раз - медленно и неэффективно!

**Как это работает:**

1. **Первый запуск приложения:**
   ```
   Пользователь открывает страницу
   ↓
   session_state.current_data = None (еще нет данных)
   ↓
   Читаем CSV файл (медленно, ~1-2 секунды)
   ↓
   Сохраняем DataFrame в session_state.current_data
   ```

2. **Второй и последующие запуски (при клике, изменении выпадающего списка и т.д.):**
   ```
   Пользователь кликает на что-то
   ↓
   Streamlit перезапускает весь скрипт
   ↓
   session_state.current_data УЖЕ содержит DataFrame (не None!)
   ↓
   Пропускаем чтение CSV (быстро!)
   ↓
   Используем данные из session_state
   ```

**Пример без session_state (плохо):**
```python
# Плохо: читаем CSV каждый раз
df = pd.read_csv("data/raw/...csv")  # Медленно! 1-2 секунды каждый раз
visualizer = DataVisualizer(df)
figures = visualizer.plot_migration_data()  # Еще 1-2 секунды
```

**Результат:** При каждом клике пользователь ждет 2-4 секунды!

**Пример с session_state (хорошо):**
```python
# Хорошо: читаем CSV только один раз
if st.session_state.current_data is None:
    df = pd.read_csv("data/raw/...csv")  # Только первый раз
    st.session_state.current_data = df

df = st.session_state.current_data  # Быстро! Просто берем из памяти
visualizer = DataVisualizer(df)
figures = visualizer.plot_migration_data()
```

**Результат:** Первый раз - 2-4 секунды, дальше - мгновенно!

**Аналогия:**
- **Без session_state:** Каждый раз идти в библиотеку за книгой (читать CSV)
- **С session_state:** Взять книгу один раз, положить на стол (session_state), использовать сколько угодно раз

**Что происходит в коде:**
1. Проверяем, загружены ли данные (`if st.session_state.current_data is None`)
2. Если нет - ищем файл миграции и читаем CSV
3. `Path("data/raw/...")` - создает объект пути к файлу
4. `migration_file.exists()` - проверяет, существует ли файл
5. `pd.read_csv(..., sep=';')` - читает CSV с разделителем `;` (немецкий формат)
6. **Сохраняем DataFrame в `session_state`** - это ключевой момент!
7. При следующих запусках скрипта `session_state.current_data` уже не `None`, поэтому пропускаем чтение CSV
8. `try/except` - если файл поврежден, просто пропускаем (не падаем с ошибкой)

**Почему `sep=';'`:**
- Немецкие CSV часто используют `;` вместо `,` (из-за запятых в числах: `1.234,56`)

### Основной контент - Визуализация (строки 86-201)

#### Проверка наличия данных (строки 89-90)

```python
if st.session_state.current_data is None:
    st.info("Daten werden automatisch geladen...")
```

**Что происходит:**
- Если данных нет - показываем сообщение пользователю
- `st.info()` - информационное сообщение (синий блок)

#### Создание визуализатора (строки 92-95)

```python
else:
    df = st.session_state.current_data
    
    visualizer = DataVisualizer(df)
```

**Что происходит:**
- Берем данные из `session_state`
- Создаем объект `DataVisualizer` - это наш "движок" для создания графиков
- Передаем ему DataFrame с данными

#### Проверка типа данных (строки 97-98)

```python
if 'herkunftsgebiet_wegzugsgebiet' in df.columns:
```

**Что происходит:**
- Проверяем, есть ли в данных колонка `herkunftsgebiet_wegzugsgebiet`
- Эта колонка - ключевая для миграционных данных
- Если есть - значит это данные миграции, и мы можем создать специальные графики

#### Создание графиков (строки 101-102)

```python
with st.spinner("Erstelle Visualisierungen..."):
    figures, available_years = visualizer.plot_migration_data()
```

**Что происходит:**
1. `st.spinner()` - показывает спиннер (крутящийся индикатор) пока создаются графики
2. Вызываем метод `plot_migration_data()` у визуализатора
3. Метод возвращает:
   - `figures` - список Plotly-графиков
   - `available_years` - список доступных годов

**Почему `with st.spinner()`:**
- Создание графиков может занять время
- Спиннер показывает пользователю, что приложение работает

#### Отображение графика 1: Временной ряд (строки 105-122)

```python
if len(figures) > 0:
    st.plotly_chart(figures[0], use_container_width=True)
    
    with st.expander("📋 Rohdaten: Gesamtmigration nach Jahren", expanded=False):
        years_data = figures[0].data[0].x
        zuzug_data = figures[0].data[0].y
        wegzug_data = figures[0].data[1].y
        
        summary_df = pd.DataFrame({
            'Jahr': years_data,
            'Zuzug': zuzug_data,
            'Wegzug': wegzug_data,
            'Saldo': [z - w for z, w in zip(zuzug_data, wegzug_data)]
        })
        st.dataframe(summary_df, use_container_width=True)
```

**Что происходит:**
1. `st.plotly_chart()` - отображает Plotly-график
   - `figures[0]` - первый график (временной ряд)
   - `use_container_width=True` - график занимает всю ширину контейнера

2. `st.expander()` - создает раскрывающийся блок "Rohdaten" (сырые данные)
   - `expanded=False` - по умолчанию свернут

3. Извлекаем данные из графика:
   - `figures[0].data[0]` - первая линия (Zuzug)
   - `figures[0].data[0].x` - годы (ось X)
   - `figures[0].data[0].y` - значения Zuzug (ось Y)
   - `figures[0].data[1].y` - значения Wegzug (вторая линия)

4. Создаем DataFrame с сырыми данными
5. `st.dataframe()` - отображает таблицу

**Почему извлекаем данные из графика:**
- Чтобы показать пользователю точные числа, которые использовались для графика
- Это повышает прозрачность и позволяет проверить расчеты

#### Отображение графика 2: Сальдо (строки 124-126)

```python
if len(figures) > 1:
    st.plotly_chart(figures[1], use_container_width=True)
```

**Что происходит:**
- Просто отображаем второй график (Migrationssaldo)
- Без сырых данных (можно добавить, если нужно)

#### Графики 3 и 4: Топ-10 стран с выбором года (строки 128-180)

```python
st.subheader("Top 10 Länder nach Zuzug und Wegzug")

if available_years:
    selected_year = st.selectbox(
        "Jahr auswählen:",
        available_years,
        index=len(available_years) - 1  # Default to last year
    )
```

**Что происходит:**
1. `st.subheader()` - подзаголовок
2. `st.selectbox()` - выпадающий список для выбора года
   - Первый аргумент - подпись
   - Второй - список опций (годы)
   - `index=...` - индекс выбранного элемента по умолчанию (последний год)

```python
if selected_year:
    try:
        fig_zuzug, fig_wegzug = visualizer.plot_top_countries_by_year(selected_year)
        
        col1, col2 = st.columns(2)
        
        with col1:
            if fig_zuzug is not None:
                st.plotly_chart(fig_zuzug, use_container_width=True)
```

**Что происходит:**
1. Вызываем `plot_top_countries_by_year()` - создает два графика для выбранного года
2. `st.columns(2)` - создает две колонки (для размещения графиков рядом)
3. `with col1:` - все внутри этого блока идет в первую колонку
4. Проверяем, что график создан (`if fig_zuzug is not None`)
5. Отображаем график

**Почему `try/except`:**
- Если данные для года отсутствуют, метод может вернуть `None`
- `try/except` обрабатывает ошибки без падения приложения

#### График 5: Динамика топ-стран (строки 182-199)

```python
if len(figures) > 2:
    st.plotly_chart(figures[2], use_container_width=True)
    # ... сырые данные
```

**Что происходит:**
- Отображаем третий график (динамика топ-5 стран)
- Аналогично первому графику, показываем сырые данные

---

## 📊 Часть 2: src/visualizer.py - Логика визуализации

### Класс DataVisualizer (строки 15-26)

```python
class DataVisualizer:
    """Klasse zur Visualisierung von Migrationsdaten"""
    
    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()
```

**Что происходит:**
- Класс - это "шаблон" для создания объектов
- `__init__()` - конструктор (вызывается при создании объекта)
- `self.df = df.copy()` - сохраняет копию DataFrame в объекте
  - `.copy()` нужен, чтобы не изменять оригинальный DataFrame

**Почему класс:**
- Инкапсуляция: данные и методы работы с ними в одном месте
- Можно создать несколько визуализаторов для разных наборов данных

### Метод _clean_country_name (строки 21-26)

```python
def _clean_country_name(self, name: str) -> str:
    """Bereinigt Ländernamen (entfernt Präfixe wie '121_')"""
    parts = name.split('_', 1)
    if len(parts) > 1 and parts[0].isdigit():
        return parts[1].replace('_', ' ').title()
    return name.replace('_', ' ').title()
```

**Что происходит:**
1. Принимает имя страны (например, `"121_ukraine"`)
2. Разделяет по `_` на две части: `["121", "ukraine"]`
3. Если первая часть - число (`isdigit()`):
   - Возвращает вторую часть, заменяя `_` на пробелы и делая заглавными первыми буквами: `"Ukraine"`
4. Иначе просто форматирует имя

**Примеры:**
- `"121_ukraine"` → `"Ukraine"`
- `"baden_wuertemberg"` → `"Baden Wuertemberg"`

**Почему `_` в начале имени:**
- Это приватный метод (не вызывается извне)
- Вспомогательная функция для форматирования

### Метод plot_migration_data - Главный метод (строки 28-362)

Это самый сложный метод. Разберем по частям:

#### Шаг 1: Проверка данных (строки 36-41)

```python
figures = []

# Check if this is migration data
if 'herkunftsgebiet_wegzugsgebiet' not in self.df.columns:
    logger.warning("Keine Migrationsdaten erkannt")
    return figures, []
```

**Что происходит:**
- Проверяем наличие ключевой колонки
- Если нет - возвращаем пустые списки

#### Шаг 2: Извлечение годов из данных (строки 43-119)

**🔍 ВАЖНО: Здесь создается переменная `years`!**

```python
key_col = 'herkunftsgebiet_wegzugsgebiet'

# Finde Zeile mit Kontinenten (für Filterung)
continent_row = None
for idx, val in enumerate(self.df[key_col]):
    if 'Kontinent' in str(val):
        continent_row = idx
        break

# Extrahiere Jahre und Typen (Zuzug/Wegzug)
years = []  # ← ВОТ ЗДЕСЬ СОЗДАЕТСЯ ПУСТОЙ СПИСОК!
zuzug_data = {}
wegzug_data = {}

for idx, row_key in enumerate(self.df[key_col]):
    if pd.isna(row_key):
        continue
    
    row_key_str = str(row_key).strip()
    
    # Parse Jahr und Typ
    if '_ Zuzug' in row_key_str:
        year = int(row_key_str.split('_')[0])  # Извлекаем год из строки "2022_ Zuzug"
        years.append(year)  # ← ДОБАВЛЯЕМ ГОД В СПИСОК
        # ... остальной код для обработки данных
```

**Что происходит:**
1. Создаем пустой список `years = []` (строка 54)
2. Проходим по всем строкам в колонке `herkunftsgebiet_wegzugsgebiet`
3. Ищем строки, содержащие `"_ Zuzug"` (например, `"2022_ Zuzug"`)
4. Извлекаем год из начала строки: `"2022_ Zuzug".split('_')[0]` → `"2022"`
5. Преобразуем в число: `int("2022")` → `2022`
6. Добавляем в список: `years.append(2022)`
7. Аналогично для `"_ Wegzug"` (хотя год уже может быть в списке)

**Пример данных:**
```
herkunftsgebiet_wegzugsgebiet
"2022_ Zuzug"     ← извлекаем 2022
"2022_ Wegzug"   ← год уже есть, не дублируем
"2023_ Zuzug"    ← извлекаем 2023
"2023_ Wegzug"   ← год уже есть
```

**После обработки всех строк:**
```python
years = sorted(set(years))  # Удаляем дубликаты и сортируем
# Результат: [2010, 2011, 2012, ..., 2023]
```

**Почему `set(years)`:**
- Один год может встречаться дважды (для Zuzug и Wegzug)
- `set()` удаляет дубликаты
- `sorted()` сортирует по возрастанию

**Результат Шага 2:**
```python
years = [2010, 2011, 2012, ..., 2023]  # Список готов к использованию!
```

#### Шаг 3: Суммирование данных по годам (строки 125-170)

**🔍 ВАЖНО: Теперь используем список `years`, созданный в Шаге 2!**

```python
# Chart 1: Time series of total migration
total_zuzug = []
total_wegzug = []

for year in years:  # ← ИСПОЛЬЗУЕМ СПИСОК, СОЗДАННЫЙ В ШАГЕ 2
    z_sum = 0
    w_sum = 0
    
    # Finde Zeile für Zuzug
    for idx, row_key in enumerate(self.df[key_col]):
        row_key_str = str(row_key).strip()
        if f'{year}_ Zuzug' in row_key_str:
            row_data = self.df.iloc[idx]
            # Summiere alle numerischen Werte in der Zeile
            for col in self.df.columns:
                if col == key_col or col == 'quelle':
                    continue
                try:
                    val = row_data[col]
                    if pd.notna(val) and str(val).strip() != '':
                        num_val = float(str(val).replace(',', '.'))
                        z_sum += num_val
                except:
                    pass
            break
```

**Что происходит:**
1. **Используем список `years`, созданный в Шаге 2** - это важно! Переменная `years` уже существует и содержит все годы из данных.
2. Для каждого года из списка ищем строку с `"2022_ Zuzug"` в колонке `herkunftsgebiet_wegzugsgebiet`
2. Когда находим - берем всю строку (`self.df.iloc[idx]`)
3. Проходим по всем колонкам (кроме служебных)
4. Преобразуем значения в числа:
   - `str(val).replace(',', '.')` - заменяем запятую на точку (немецкий формат)
   - `float(...)` - преобразуем в число
5. Суммируем все значения в строке
6. Аналогично для Wegzug

**Почему суммируем всю строку:**
- В данных каждая страна - это отдельная колонка
- Чтобы получить общее количество Zuzug за год, нужно сложить все страны

**Последовательность выполнения:**
```
Шаг 2 (строки 53-119):
  years = []                    ← СОЗДАЕМ ПУСТОЙ СПИСОК
  for row in data:
      if "_ Zuzug" in row:
          year = extract_year()  ← ИЗВЛЕКАЕМ ГОД
          years.append(year)    ← ДОБАВЛЯЕМ В СПИСОК
  years = sorted(set(years))    ← УДАЛЯЕМ ДУБЛИКАТЫ
  # Результат: years = [2010, 2011, ..., 2023]
         ↓
Шаг 3 (строки 125-170):
  for year in years:            ← ИСПОЛЬЗУЕМ СПИСОК, СОЗДАННЫЙ В ШАГЕ 2!
      # Суммируем данные для этого года
```

**Важно понимать:**
- `years` создается в Шаге 2 (строки 53-119)
- `years` используется в Шаге 3 (строка 130: `for year in years:`)
- Это одна и та же переменная, просто создается раньше, чем используется

#### Шаг 4: Создание графика 1 - Временной ряд (строки 172-211)

**Используем данные из Шага 3: `years`, `total_zuzug`, `total_wegzug`**

```python
fig1 = go.Figure()
fig1.add_trace(go.Scatter(
    x=years,
    y=total_zuzug,
    mode='lines+markers',
    name='Zuzug (Ankunft)',
    line=dict(color='#2ecc71', width=3),
    marker=dict(size=8)
))
fig1.add_trace(go.Scatter(
    x=years,
    y=total_wegzug,
    mode='lines+markers',
    name='Wegzug (Abgang)',
    line=dict(color='#e74c3c', width=3),
    marker=dict(size=8)
))
```

**Что происходит:**
1. `go.Figure()` - создает пустой график Plotly
2. `add_trace()` - добавляет линию данных
   - `go.Scatter()` - тип графика (линия с точками)
   - `x=years` - ось X (годы)
   - `y=total_zuzug` - ось Y (значения)
   - `mode='lines+markers'` - линия + точки
   - `name` - название для легенды
   - `line=dict(...)` - настройки линии (цвет, ширина)
   - `marker=dict(...)` - настройки точек (размер)

3. Добавляем вторую линию (Wegzug)

```python
fig1.update_layout(
    title='Außenwanderung Konstanz 2010-2023',
    xaxis_title='Jahr',
    yaxis_title='Anzahl Personen',
    template='plotly_white',
    hovermode='x unified',
    legend=dict(yanchor="top", y=0.99, xanchor="left", x=0.01),
    margin=dict(l=60, r=60, t=60, b=100),
    xaxis=dict(title_standoff=15),
    annotations=[...]
)
```

**Что происходит:**
- `update_layout()` - настраивает внешний вид графика
- `title` - заголовок
- `xaxis_title`, `yaxis_title` - подписи осей
- `template='plotly_white'` - белый фон
- `hovermode='x unified'` - при наведении показывать оба значения для года
- `legend=dict(...)` - позиция легенды
- `margin=dict(...)` - отступы (left, right, top, bottom)
- `annotations` - текст внизу графика (пояснения)

#### Шаг 5: График 2 - Сальдо (строки 213-245)

```python
saldo = [z - w for z, w in zip(total_zuzug, total_wegzug)]

colors = ['#2ecc71' if s > 0 else '#e74c3c' for s in saldo]

fig2 = go.Figure()
fig2.add_trace(go.Bar(
    x=years,
    y=saldo,
    name='Migrationssaldo',
    marker_color=colors,
    text=[f'+{s:.0f}' if s > 0 else f'{s:.0f}' for s in saldo],
    textposition='outside'
))
```

**Что происходит:**
1. Вычисляем сальдо: `[z - w for z, w in zip(...)]`
   - `zip()` объединяет два списка попарно
   - Для каждой пары вычисляем разность

2. Цвета: зеленый для положительных, красный для отрицательных

3. `go.Bar()` - столбчатый график
   - `marker_color=colors` - каждый столбец своего цвета
   - `text=[...]` - текст на столбцах (значения)
   - `textposition='outside'` - текст снаружи столбца

#### Шаг 6: График 3 - Динамика топ-стран (строки 247-362)

Это самый сложный график. Разберем логику:

##### Определение топ-5 стран (строки 249-281)

```python
# Determine top countries (based on max absolute saldo across all years)
country_max_abs_saldo = {}
for year in years:
    # ... находим строки для года (zuzug_row_idx, wegzug_row_idx)
    zuzug_data_row = self.df.iloc[zuzug_row_idx]
    wegzug_data_row = self.df.iloc[wegzug_row_idx]
    
    for col in self.df.columns:
        # Извлекаем значения для страны (col)
        z_val = zuzug_data_row[col]  # Значение Zuzug для этой страны
        w_val = wegzug_data_row[col]  # Значение Wegzug для этой страны
        
        # Преобразуем в числа (z = Zuzug, w = Wegzug)
        z = float(str(z_val).replace(',', '.')) if pd.notna(z_val) else 0
        w = float(str(w_val).replace(',', '.')) if pd.notna(w_val) else 0
        
        abs_saldo = abs(z - w)  # Абсолютное значение сальдо
        # Keep maximum absolute saldo for each country
        if col not in country_max_abs_saldo or abs_saldo > country_max_abs_saldo[col]:
            country_max_abs_saldo[col] = abs_saldo

sorted_countries_by_saldo = sorted(country_max_abs_saldo.items(), key=lambda x: x[1], reverse=True)
top_countries = [c[0] for c in sorted_countries_by_saldo[:5]]
```

**Что происходит:**
1. Для каждого года находим строки с данными Zuzug и Wegzug
2. Для каждой страны (колонки) извлекаем:
   - `z` = значение **Z**uzug (иммиграция, приезд) для этой страны
   - `w` = значение **W**egzug (эмиграция, отъезд) для этой страны
3. Вычисляем абсолютное значение сальдо: `abs(z - w)`
4. Сохраняем максимальное значение сальдо для каждой страны (за все годы)
5. Сортируем страны по максимальному сальдо (убывание)
6. Берем топ-5

**Обозначения:**
- `z` = **Z**uzug (иммиграция, приезд)
- `w` = **W**egzug (эмиграция, отъезд)
- `abs(z - w)` = абсолютное значение миграционного сальдо

**Почему максимальное сальдо, а не сумма:**
- Украина в 2022 году имеет огромный пик (1253)
- Но по сумме за все годы она только 6-я
- Используя максимум, мы включаем страны с значительными пиками

##### Сбор данных по годам для топ-стран (строки 283-318)

```python
country_yearly_data = {country: {'zuzug': [], 'wegzug': [], 'saldo': []} for country in top_countries}

for year in years:
    # ... находим строки для года
    for country_col in top_countries:
        z_val = zuzug_row[country_col]
        w_val = wegzug_row[country_col]
        z = float(str(z_val).replace(',', '.')) if pd.notna(z_val) else 0
        w = float(str(w_val).replace(',', '.')) if pd.notna(w_val) else 0
        
        country_yearly_data[country_col]['zuzug'].append(z)
        country_yearly_data[country_col]['wegzug'].append(w)
        country_yearly_data[country_col]['saldo'].append(z - w)
```

**Что происходит:**
1. Создаем словарь для каждой топ-страны с тремя списками
2. Для каждого года извлекаем данные для топ-стран
3. Заполняем списки значениями по годам

##### Создание графика (строки 320-360)

```python
fig3 = go.Figure()

colors = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6']
for idx, country_col in enumerate(top_countries):
    country_name = self._clean_country_name(country_col)
    saldo_data = country_yearly_data[country_col]['saldo']
    
    fig3.add_trace(go.Scatter(
        x=years,
        y=saldo_data,
        mode='lines+markers',
        name=country_name,
        line=dict(color=colors[idx % len(colors)], width=2),
        marker=dict(size=6)
    ))
```

**Что происходит:**
1. Создаем график
2. Для каждой топ-страны добавляем линию:
   - Цвет берется из списка (циклически через `%`)
   - Данные - список сальдо по годам
   - Имя страны форматируется через `_clean_country_name()`

### Метод plot_top_countries_by_year (строки 364-512)

Этот метод создает два графика для выбранного года.

#### Извлечение данных для года (строки 379-394)

```python
# Finde Zeilen für das ausgewählte Jahr
zuzug_row = None
wegzug_row = None

for idx, row_key in enumerate(self.df[key_col]):
    row_key_str = str(row_key).strip()
    if f'{selected_year}_ Zuzug' in row_key_str:
        zuzug_row = idx
    elif f'{selected_year}_ Wegzug' in row_key_str:
        wegzug_row = idx
```

**Что происходит:**
- Ищем индексы строк для Zuzug и Wegzug выбранного года

#### Сбор данных по странам (строки 396-430)

```python
zuzug_totals = {}
for col in self.df.columns:
    if col == key_col or col == 'quelle':
        continue
    if col in ['sonstige_staaten', 'unbekannt_ohne_angaben']:
        continue
    
    try:
        z_val = zuzug_data_row[col]
        z = 0
        if pd.notna(z_val) and str(z_val).strip() != '' and str(z_val).strip() != 'nan':
            z = float(str(z_val).replace(',', '.'))
        if z > 0:
            zuzug_totals[col] = z
    except:
        pass
```

**Что происходит:**
1. Проходим по всем колонкам (странам)
2. Пропускаем служебные колонки
3. Извлекаем значение для страны
4. Если значение > 0 - добавляем в словарь
5. Аналогично для Wegzug

#### Создание графиков (строки 432-512)

```python
sorted_zuzug = sorted(zuzug_totals.items(), key=lambda x: x[1], reverse=True)[:10]
countries_z = [self._clean_country_name(c[0]) for c in sorted_zuzug]
values_z = [float(c[1]) for c in sorted_zuzug]

fig_zuzug = go.Figure()
fig_zuzug.add_trace(go.Bar(
    x=values_z,
    y=countries_z,
    orientation='h',  # horizontal bar chart
    marker_color='#2ecc71',
    text=[f'{v:.0f}' for v in values_z],
    textposition='outside'
))
```

**Что происходит:**
1. Сортируем страны по значению (убывание)
2. Берем топ-10
3. Форматируем имена стран
4. Создаем горизонтальный столбчатый график (`orientation='h'`)
   - X - значения
   - Y - страны (сверху вниз)

---

## 🔄 Поток данных

```
1. Пользователь открывает приложение
   ↓
2. app.py загружается
   ↓
3. Проверяется session_state.current_data
   ↓
4. Если None - загружается CSV файл
   ↓
5. DataFrame сохраняется в session_state
   ↓
6. Создается DataVisualizer(df)
   ↓
7. Вызывается plot_migration_data()
   ↓
8. Метод обрабатывает данные:
   - Извлекает годы
   - Суммирует Zuzug/Wegzug по годам
   - Определяет топ-5 стран
   - Собирает данные по годам для топ-стран
   ↓
9. Создаются Plotly-графики
   ↓
10. Графики возвращаются в app.py
   ↓
11. app.py отображает графики через st.plotly_chart()
   ↓
12. Пользователь видит визуализации
```

---

## 🎯 Ключевые концепции

### 1. Session State
- Сохраняет данные между перезагрузками страницы
- Критично для Streamlit-приложений

### 2. DataFrame (Pandas)
- Табличная структура данных
- Позволяет легко фильтровать, группировать, суммировать

### 3. Plotly
- Библиотека для интерактивных графиков
- `go.Figure()` - контейнер для графика
- `add_trace()` - добавляет данные
- `update_layout()` - настраивает внешний вид

### 4. Обработка данных
- Немецкий формат чисел: `"1.234,56"` → `float("1.234,56".replace(',', '.'))`
- Проверка на `NaN`: `pd.notna(val)`
- Безопасное преобразование: `try/except`

---

## 📝 Резюме

**app.py:**
- Пользовательский интерфейс
- Загрузка данных
- Отображение графиков
- Управление состоянием (session_state)

**visualizer.py:**
- Обработка данных
- Создание графиков
- Бизнес-логика визуализации

**Взаимодействие:**
- app.py вызывает методы visualizer.py
- visualizer.py возвращает готовые графики
- app.py отображает их пользователю

Это классическая архитектура MVC (Model-View-Controller):
- **Model** (visualizer.py) - логика
- **View** (app.py) - интерфейс
- **Controller** (app.py) - координация

