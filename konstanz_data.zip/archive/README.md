# Archive

Diese Dateien sind nicht mehr aktiv im Projekt verwendet, werden aber für Referenzzwecke aufbewahrt.

## Inhalt

- `app_backup.py` - Backup-Version der App
- `test_*.py` - Test-Scripts
- `check_ukraine_data.py` - Debug-Script
- `download_konstanz_data.py` - Alte Download-Version
- `run.py` - Alte Start-Script
- `setup.py` - Setup-Script (nicht mehr benötigt)


