"""
Modul zur Analyse von Statistikdaten
- Einwohnerentwicklung
- Altersgruppen
- Wohnen / Verkehr
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DataAnalyzer:
    """Klasse zur Analyse von Statistikdaten"""
    
    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()
        self.analyses = {}
    
    def analyze_population_development(self, 
                                      year_column: str = 'jahr',
                                      population_column: str = 'einwohner') -> Dict:
        """
        Analysiert die Einwohnerentwicklung
        
        Args:
            year_column: Name der Spalte mit Jahren
            population_column: Name der Spalte mit Einwohnerzahlen
            
        Returns:
            Dictionary mit Analyseergebnissen
        """
        if year_column not in self.df.columns or population_column not in self.df.columns:
            logger.warning(f"Spalten nicht gefunden: {year_column} oder {population_column}")
            return {}
        
        # Bereinige Daten
        data = self.df[[year_column, population_column]].copy()
        data = data.dropna()
        
        if len(data) == 0:
            return {}
        
        # Sortiere nach Jahr
        data = data.sort_values(year_column)
        
        analysis = {
            'zeitraum': {
                'von': int(data[year_column].min()),
                'bis': int(data[year_column].max()),
            },
            'entwicklung': {
                'start': float(data[population_column].iloc[0]),
                'ende': float(data[population_column].iloc[-1]),
                'veraenderung_absolut': float(data[population_column].iloc[-1] - data[population_column].iloc[0]),
                'veraenderung_prozent': float((data[population_column].iloc[-1] / data[population_column].iloc[0] - 1) * 100),
            },
            'durchschnitt': float(data[population_column].mean()),
            'datenpunkte': len(data),
        }
        
        # Berechne jährliche Veränderung
        if len(data) > 1:
            data['veraenderung'] = data[population_column].diff()
            analysis['durchschnittliche_jaehrliche_veraenderung'] = float(data['veraenderung'].mean())
        
        self.analyses['einwohnerentwicklung'] = analysis
        logger.info("Einwohnerentwicklung analysiert")
        return analysis
    
    def analyze_age_groups(self, 
                          age_column: str = 'alter',
                          count_column: Optional[str] = None) -> Dict:
        """
        Analysiert Altersgruppen
        
        Args:
            age_column: Name der Spalte mit Alter/Altersgruppe
            count_column: Name der Spalte mit Anzahl (wenn None, wird gezählt)
            
        Returns:
            Dictionary mit Analyseergebnissen
        """
        if age_column not in self.df.columns:
            logger.warning(f"Spalte nicht gefunden: {age_column}")
            return {}
        
        # Definiere Altersgruppen
        age_groups = {
            '0-17': (0, 17),
            '18-29': (18, 29),
            '30-44': (30, 44),
            '45-59': (45, 59),
            '60-74': (60, 74),
            '75+': (75, 200),
        }
        
        analysis = {
            'altersgruppen': {},
            'gesamt': 0,
        }
        
        if count_column and count_column in self.df.columns:
            # Verwende vorhandene Zählspalte
            for group_name, (min_age, max_age) in age_groups.items():
                mask = (self.df[age_column] >= min_age) & (self.df[age_column] <= max_age)
                count = float(self.df[mask][count_column].sum())
                analysis['altersgruppen'][group_name] = count
                analysis['gesamt'] += count
        else:
            # Zähle Zeilen
            for group_name, (min_age, max_age) in age_groups.items():
                mask = (self.df[age_column] >= min_age) & (self.df[age_column] <= max_age)
                count = int(mask.sum())
                analysis['altersgruppen'][group_name] = count
                analysis['gesamt'] += count
        
        # Berechne Prozente
        if analysis['gesamt'] > 0:
            for group_name in analysis['altersgruppen']:
                count = analysis['altersgruppen'][group_name]
                analysis['altersgruppen'][group_name] = {
                    'anzahl': count,
                    'prozent': float(count / analysis['gesamt'] * 100)
                }
        
        self.analyses['altersgruppen'] = analysis
        logger.info("Altersgruppen analysiert")
        return analysis
    
    def analyze_housing(self,
                       housing_type_column: Optional[str] = None,
                       count_column: Optional[str] = None) -> Dict:
        """
        Analysiert Wohnungsdaten
        
        Args:
            housing_type_column: Name der Spalte mit Wohnungstyp
            count_column: Name der Spalte mit Anzahl
            
        Returns:
            Dictionary mit Analyseergebnissen
        """
        analysis = {
            'wohnungstypen': {},
            'gesamt': 0,
        }
        
        # Versuche, relevante Spalten zu finden
        if housing_type_column is None:
            # Suche nach Spalten mit "wohnung", "typ", etc.
            for col in self.df.columns:
                if any(keyword in col.lower() for keyword in ['wohnung', 'typ', 'art']):
                    housing_type_column = col
                    break
        
        if housing_type_column and housing_type_column in self.df.columns:
            if count_column and count_column in self.df.columns:
                grouped = self.df.groupby(housing_type_column)[count_column].sum()
            else:
                grouped = self.df.groupby(housing_type_column).size()
            
            total = float(grouped.sum())
            analysis['gesamt'] = total
            
            for housing_type, count in grouped.items():
                analysis['wohnungstypen'][str(housing_type)] = {
                    'anzahl': float(count),
                    'prozent': float(count / total * 100) if total > 0 else 0
                }
        
        self.analyses['wohnen'] = analysis
        logger.info("Wohnungsdaten analysiert")
        return analysis
    
    def get_summary(self) -> Dict:
        """
        Gibt eine Zusammenfassung aller Analysen zurück
        
        Returns:
            Dictionary mit allen Analysen
        """
        summary = {
            'anzahl_zeilen': len(self.df),
            'anzahl_spalten': len(self.df.columns),
            'spalten': list(self.df.columns),
            'analysen': self.analyses,
        }
        
        return summary


def analyze_data(df: pd.DataFrame) -> Dict:
    """
    Hauptfunktion zur Analyse von Daten
    
    Args:
        df: DataFrame mit Daten
        
    Returns:
        Dictionary mit Analyseergebnissen
    """
    analyzer = DataAnalyzer(df)
    
    # Führe verschiedene Analysen durch
    analyzer.analyze_population_development()
    analyzer.analyze_age_groups()
    analyzer.analyze_housing()
    
    return analyzer.get_summary()


if __name__ == "__main__":
    # Test
    test_data = pd.DataFrame({
        'jahr': [2020, 2021, 2022, 2023],
        'einwohner': [85000, 86000, 87000, 88000],
        'alter': [25, 30, 45, 60],
    })
    
    results = analyze_data(test_data)
    print(results)


