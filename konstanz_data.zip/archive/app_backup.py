"""
Streamlit App für Konstanz Open Data Explorer
Mini-Web-App zur Analyse und Visualisierung von Statistikdaten
"""

import streamlit as st
import pandas as pd
from pathlib import Path
import sys
import io
import json

# Füge src zum Pfad hinzu
sys.path.append(str(Path(__file__).parent))

from src.downloader import DataDownloader, download_statistics
from src.standardizer import standardize_data, DataStandardizer
from src.analyzer import analyze_data, DataAnalyzer
from src.visualizer import create_overview, DataVisualizer
from src.exporter import export_dataset, DataExporter

# PDF-Unterstützung
try:
    import pdfplumber
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False
    st.warning("PDF-Unterstützung nicht verfügbar. Installieren Sie pdfplumber: pip install pdfplumber")


def extract_data_from_pdf(uploaded_file) -> pd.DataFrame:
    """
    Extrahiert Tabellendaten aus einer PDF-Datei
    
    Args:
        uploaded_file: Streamlit UploadedFile Objekt
        
    Returns:
        DataFrame mit extrahierten Daten oder None
    """
    if not PDF_SUPPORT:
        st.error("PDF-Unterstützung nicht verfügbar. Bitte installieren Sie pdfplumber.")
        return None
    
    try:
        # Lese PDF in Bytes
        pdf_bytes = uploaded_file.read()
        pdf_file = io.BytesIO(pdf_bytes)
        
        # Extrahiere Tabellen aus PDF
        tables = []
        with pdfplumber.open(pdf_file) as pdf:
            for page in pdf.pages:
                page_tables = page.extract_tables()
                if page_tables:
                    tables.extend(page_tables)
        
        if not tables:
            return None
        
        # Konvertiere erste Tabelle zu DataFrame
        if tables:
            # Erste Zeile als Header verwenden
            first_table = tables[0]
            if len(first_table) > 1:
                df = pd.DataFrame(first_table[1:], columns=first_table[0])
                # Bereinige DataFrame
                df = df.dropna(how='all')  # Entferne leere Zeilen
                df = df.loc[:, ~df.columns.duplicated()]  # Entferne doppelte Spalten
                return df
        
        return None
        
    except Exception as e:
        st.error(f"Fehler beim Extrahieren von PDF-Daten: {e}")
        return None

# Konfiguration
st.set_page_config(
    page_title="Konstanz Open Data Explorer",
    page_icon="📊",
    layout="wide"
)

# Titel
st.title("📊 Konstanz Open Data Explorer")
st.markdown("**Prototyp eines Werkzeugs zur Analyse und Strukturierung offener Statistikdaten der Stadt Konstanz**")

# Источник данных
with st.expander("ℹ️ Datenquelle", expanded=False):
    st.markdown("""
    **Datenquelle:** [Open Data Konstanz](https://offenedaten-konstanz.de/)
    
    **Aktueller Datensatz:** Außenwanderung nach Herkunfts- und Zielgebiet (2010-2023)
    
    **Datenformat:** CSV mit Semikolon-Trennung (deutsches Format)
    
    **Schritte für andere Datenquellen:**
    1. CSV/Excel/PDF-Datei von Open Data Portal herunterladen
    2. Datei hier hochladen oder in `data/raw/` speichern
    3. Daten werden automatisch erkannt und visualisiert
    4. Weitere Details siehe [Anleitung](ANLEITUNG.md)
    """)

# Sidebar - только информация о приложении
st.sidebar.title("Konstanz Open Data Explorer")
st.sidebar.markdown("**Version 0.1.0**")
st.sidebar.markdown("---")
st.sidebar.markdown("""
**Prototyp eines Werkzeugs zur Analyse und Strukturierung offener Statistikdaten der Stadt Konstanz**

[Datenquelle](https://offenedaten-konstanz.de/)
""")

# Datenverzeichnisse
DATA_DIR = Path("data")
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
OUTPUT_DIR = Path("output")

# Erstelle Verzeichnisse
for dir_path in [RAW_DIR, PROCESSED_DIR, OUTPUT_DIR]:
    dir_path.mkdir(parents=True, exist_ok=True)

# Session State
if 'datasets' not in st.session_state:
    st.session_state.datasets = {}
if 'current_data' not in st.session_state:
    st.session_state.current_data = None
if 'current_file' not in st.session_state:
    st.session_state.current_file = None

# Автоматически загружаем файл миграции при старте
if st.session_state.current_data is None:
    migration_file = Path("data/raw/Aussenwanderung_nach_Herkunfts_Ziel-Staat_2010-2023_0_0.csv")
    if migration_file.exists():
        try:
            df = pd.read_csv(migration_file, sep=';', encoding='utf-8')
            st.session_state.current_data = df
            st.session_state.current_file = migration_file.name
        except:
            pass

# Основной контент - только визуализация
    st.header("1️⃣ Daten abrufen")
    
    st.markdown("""
    **Datenquelle:** [Open Data Konstanz](https://offenedaten-konstanz.de/)
    
    **Hinweis:** Für andere Datenquellen siehe [Dokumentation](README.md) oder Spalte "Datenquelle" oben.
    """)
    
    # Automatisches Herunterladen vorübergehend deaktiviert
    # if st.button("Daten herunterladen"):
    #     with st.spinner("Suche nach verfügbaren Datensätzen..."):
    #         try:
    #             datasets = download_statistics()
    #             st.session_state.datasets = {i: ds for i, ds in enumerate(datasets)}
    #             st.success(f"Gefunden: {len(datasets)} Datensätze")
    #             
    #             # Zeige Metadaten
    #             for i, dataset in enumerate(datasets):
    #                 with st.expander(f"Datensatz {i+1}: {dataset.get('dateiname', 'Unbekannt')}"):
    #                     st.json(dataset)
    #         except Exception as e:
    #             st.error(f"Fehler beim Herunterladen: {e}")
    
    # Verfügbare Dateien aus data/raw
    st.subheader("📁 Verfügbare Daten (Konstanz 2022)")
    
    raw_dir = Path("data/raw")
    metadata_file = raw_dir / "download_metadata.json"
    
    # Lade Metadaten
    metadata = {}
    if metadata_file.exists():
        try:
            with open(metadata_file, 'r', encoding='utf-8') as f:
                metadata_list = json.load(f)
                for item in metadata_list:
                    metadata[item['filename']] = item
        except:
            pass
    
    if raw_dir.exists():
        csv_files = sorted(list(raw_dir.glob("*.csv")))
        if csv_files:
            st.info(f"**{len(csv_files)} CSV-Dateien verfügbar (2022)**")
            
            # Wähle Datei aus
            file_options = {}
            for file in csv_files:
                file_meta = metadata.get(file.name, {})
                title = file_meta.get('title', file.stem.replace('_', ' '))
                file_options[title] = file
            
            selected_title = st.selectbox(
                "Wähle einen Datensatz:",
                list(file_options.keys())
            )
            
            if selected_title:
                selected_file = file_options[selected_title]
                file_meta = metadata.get(selected_file.name, {})
                description = file_meta.get('description', '')
                tags = file_meta.get('tags', [])
                
                # Zeige Beschreibung
                if description:
                    import re
                    clean_desc = re.sub(r'<[^>]+>', '', description)
                    clean_desc = clean_desc.replace('&nbsp;', ' ').strip()
                    if clean_desc:
                        st.markdown(f"**Beschreibung:** {clean_desc}")
                
                if tags:
                    st.markdown(f"**Tags:** {', '.join(tags)}")
                
                # Lade Datei automatisch
                if st.session_state.get('current_file') != selected_file.name:
                    try:
                        with st.spinner(f"Lade {selected_file.name}..."):
                            df = pd.read_csv(selected_file, sep=';', encoding='utf-8')
                            st.session_state.current_data = df
                            st.session_state.current_file = selected_file.name
                            st.session_state.current_file_meta = file_meta
                    except Exception as e:
                        st.error(f"Fehler beim Laden: {e}")
                
                # Zeige Daten
                if st.session_state.current_data is not None and st.session_state.get('current_file') == selected_file.name:
                    df = st.session_state.current_data
                    st.success(f"✅ **{selected_file.name}** geladen")
                    st.info(f"📊 {len(df)} Zeilen, {len(df.columns)} Spalten")
                    st.dataframe(df.head(20))
        else:
            st.warning("Keine CSV-Dateien gefunden. Führen Sie `scripts/download_direct.py` aus.")
    else:
        st.warning("Verzeichnis `data/raw/` existiert nicht.")
    
    st.divider()
    
    # Manueller Upload (optional)
    st.subheader("📤 Eigene Datei hochladen (optional)")
    uploaded_file = st.file_uploader(
        "Wähle eine CSV, Excel oder PDF-Datei",
        type=['csv', 'xlsx', 'xls', 'pdf']
    )
    
    if uploaded_file is not None:
        try:
            file_ext = uploaded_file.name.split('.')[-1].lower()
            
            df = None
            
            if file_ext == 'csv':
                df = pd.read_csv(uploaded_file, sep=';', encoding='utf-8')
            elif file_ext in ['xlsx', 'xls']:
                df = pd.read_excel(uploaded_file)
            elif file_ext == 'pdf':
                # PDF-Verarbeitung
                with st.spinner("PDF-Datei wird analysiert... (Tabellenerkennung kann Zeit in Anspruch nehmen)"):
                    df = extract_data_from_pdf(uploaded_file)
                if df is None or df.empty:
                    st.warning("Keine Tabellendaten in der PDF-Datei gefunden. Versuchen Sie es mit einer CSV oder Excel-Datei.")
                    df = None
            else:
                st.error(f"Nicht unterstütztes Dateiformat: {file_ext}")
                df = None
            
            if df is not None and not df.empty:
                st.session_state.current_data = df
                st.success(f"Datei geladen: {uploaded_file.name} ({len(df)} Zeilen, {len(df.columns)} Spalten)")
                st.dataframe(df.head(20))
                
        except Exception as e:
            st.error(f"Fehler beim Laden der Datei: {e}")
            import traceback
            st.code(traceback.format_exc())

# Seite: Daten analysieren
elif page == "Daten analysieren":
    st.header("2️⃣ Daten standardisieren und analysieren")
    
    if st.session_state.current_data is None:
        st.info("Bitte lade zuerst Daten auf der Seite 'Daten herunterladen'")
    else:
        df = st.session_state.current_data
        
        st.subheader("Originaldaten")
        st.dataframe(df.head(10))
        st.write(f"Zeilen: {len(df)}, Spalten: {len(df.columns)}")
        
        if st.button("Daten standardisieren"):
            with st.spinner("Standardisiere Daten..."):
                standardized_df = standardize_data(df)
                st.session_state.current_data = standardized_df
                st.success("Daten standardisiert!")
        
        if st.button("Probleme erkennen"):
            standardizer = DataStandardizer()
            standardizer.df = df
            problems = standardizer.detect_problems(df)
            
            st.subheader("Gefundene Probleme")
            st.json(problems)
        
        if st.button("Daten analysieren"):
            with st.spinner("Analysiere Daten..."):
                analysis = analyze_data(df)
                st.session_state.analysis = analysis
                
                st.subheader("Analyseergebnisse")
                st.json(analysis)

# Основной контент - только визуализация
st.header("📊 Visualisierung")

if st.session_state.current_data is None:
        st.info("Bitte lade zuerst Daten auf der Seite 'Daten abrufen'")
    else:
        df = st.session_state.current_data
        
        # Prüfe Datentyp und zeige passende Visualisierungen
        visualizer = DataVisualizer(df)
        
        # Spezielle Visualisierung für Migrationsdaten
        if 'herkunftsgebiet_wegzugsgebiet' in df.columns:
            st.subheader("Außenwanderung Konstanz 2010-2023")
            
            with st.spinner("Erstelle Visualisierungen..."):
                figures, available_years = visualizer.plot_migration_data()
                
                if figures:
                    # График 1: Временной ряд
                    if len(figures) > 0:
                        st.plotly_chart(figures[0], use_container_width=True)
                        
                        # Показываем сырые данные для этого графика
                        with st.expander("📋 Rohdaten: Gesamtmigration nach Jahren", expanded=False):
                            # Извлекаем данные из графика
                            years_data = figures[0].data[0].x
                            zuzug_data = figures[0].data[0].y
                            wegzug_data = figures[0].data[1].y
                            
                            summary_df = pd.DataFrame({
                                'Jahr': years_data,
                                'Zuzug': zuzug_data,
                                'Wegzug': wegzug_data,
                                'Saldo': [z - w for z, w in zip(zuzug_data, wegzug_data)]
                            })
                            st.dataframe(summary_df, use_container_width=True)
                    
                    # График 2: Сальдо
                    if len(figures) > 1:
                        st.plotly_chart(figures[1], use_container_width=True)
                    
                    # График 3 и 4: Топ-10 стран по Zuzug и Wegzug (с выбором года)
                    st.subheader("Top 10 Länder nach Zuzug und Wegzug")
                    
                    # Выпадающий список для выбора года
                    if available_years:
                        selected_year = st.selectbox(
                            "Jahr auswählen:",
                            available_years,
                            index=len(available_years) - 1  # По умолчанию последний год
                        )
                        
                        if selected_year:
                            try:
                                fig_zuzug, fig_wegzug = visualizer.plot_top_countries_by_year(selected_year)
                                
                                col1, col2 = st.columns(2)
                                
                                with col1:
                                    if fig_zuzug is not None:
                                        st.plotly_chart(fig_zuzug, use_container_width=True)
                                        
                                        with st.expander("📋 Rohdaten: Top 10 Zuzug", expanded=False):
                                            countries_z = fig_zuzug.data[0].y
                                            values_z = fig_zuzug.data[0].x
                                            zuzug_df = pd.DataFrame({
                                                'Land': countries_z,
                                                f'Zuzug {selected_year}': values_z
                                            })
                                            st.dataframe(zuzug_df, use_container_width=True)
                                            st.caption(f"Anzahl der Zuzüge (Ankünfte) aus jedem Land im Jahr {selected_year}")
                                    else:
                                        st.warning("Keine Zuzug-Daten verfügbar für dieses Jahr")
                                
                                with col2:
                                    if fig_wegzug is not None:
                                        st.plotly_chart(fig_wegzug, use_container_width=True)
                                        
                                        with st.expander("📋 Rohdaten: Top 10 Wegzug", expanded=False):
                                            countries_w = fig_wegzug.data[0].y
                                            values_w = fig_wegzug.data[0].x
                                            wegzug_df = pd.DataFrame({
                                                'Land': countries_w,
                                                f'Wegzug {selected_year}': values_w
                                            })
                                            st.dataframe(wegzug_df, use_container_width=True)
                                            st.caption(f"Anzahl der Fortzüge (Abgänge) in jedes Land im Jahr {selected_year}")
                                    else:
                                        st.warning("Keine Wegzug-Daten verfügbar für dieses Jahr")
                            except Exception as e:
                                st.error(f"Fehler beim Erstellen der Grafiken: {e}")
                                st.exception(e)
                    else:
                        st.warning("Keine Jahre verfügbar")
                    
                    # График 5: Динамика топ-стран
                    if len(figures) > 2:
                        st.plotly_chart(figures[2], use_container_width=True)
                        st.caption("**Hinweis:** Migrationssaldo = Zuzug - Wegzug. Positive Werte bedeuten Netto-Zuzug (mehr Menschen ziehen zu als weg), negative Werte bedeuten Netto-Wegzug.")
                        
                        # Показываем сырые данные для динамики
                        with st.expander("📋 Rohdaten: Migrationssaldo Top 5 Länder nach Jahren", expanded=False):
                            # Извлекаем данные из графика
                            years_dyn = figures[2].data[0].x
                            countries_dyn = [trace.name for trace in figures[2].data]
                            saldo_data = {country: trace.y for country, trace in zip(countries_dyn, figures[2].data)}
                            
                            dyn_df = pd.DataFrame({
                                'Jahr': years_dyn,
                                **{country: saldo_data[country] for country in countries_dyn}
                            })
                            st.dataframe(dyn_df, use_container_width=True)
                            st.caption("Migrationssaldo = Zuzug - Wegzug. Beispiel: Ukraine 2022: 1478 Zuzug - 225 Wegzug = 1253 Saldo")
                else:
                    st.warning("Konnte keine Visualisierungen erstellen")
        
        # Standard-Visualisierungen
        else:
            st.subheader("Verfügbare Visualisierungen")
            
            # Einwohnerentwicklung
            if 'jahr' in df.columns and 'einwohner' in df.columns:
                st.subheader("Einwohnerentwicklung")
                fig = visualizer.plot_population_development()
                if fig:
                    st.plotly_chart(fig, use_container_width=True)
            
            # Altersverteilung
            if 'alter' in df.columns:
                st.subheader("Altersverteilung")
                fig = visualizer.plot_age_distribution()
                if fig:
                    st.plotly_chart(fig, use_container_width=True)
            
            # Allgemeine Übersicht
            if st.button("Alle Grafiken erstellen"):
                with st.spinner("Erstelle Grafiken..."):
                    figures = visualizer.create_overview(str(OUTPUT_DIR))
                    st.success(f"Erstellt: {len(figures)} Grafiken")
                    st.info(f"Gespeichert in: {OUTPUT_DIR}")


# Footer
st.sidebar.markdown("---")
st.sidebar.markdown("**Konstanz Open Data Explorer**")
st.sidebar.markdown("Version 0.1.0")

