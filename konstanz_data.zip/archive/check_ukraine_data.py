import pandas as pd

df = pd.read_csv('data/raw/Aussenwanderung_nach_Herkunfts_Ziel-Staat_2010-2023_0_0.csv', sep=';', encoding='utf-8')

# Найдем колонку с Украиной
ukraine_col = None
for col in df.columns:
    if 'ukraine' in col.lower():
        ukraine_col = col
        break

print(f"Ukraine column: {ukraine_col}")

# Данные за 2022
zuzug_2022_row = df[df['herkunftsgebiet_wegzugsgebiet'].str.contains('2022_ Zuzug', na=False)]
wegzug_2022_row = df[df['herkunftsgebiet_wegzugsgebiet'].str.contains('2022_ Wegzug', na=False)]

if not zuzug_2022_row.empty and not wegzug_2022_row.empty:
    zuzug_2022 = zuzug_2022_row[ukraine_col].iloc[0]
    wegzug_2022 = wegzug_2022_row[ukraine_col].iloc[0]
    
    z_2022 = float(str(zuzug_2022).replace(',', '.')) if pd.notna(zuzug_2022) else 0
    w_2022 = float(str(wegzug_2022).replace(',', '.')) if pd.notna(wegzug_2022) else 0
    
    print(f"\n2022:")
    print(f"  Zuzug: {z_2022}")
    print(f"  Wegzug: {w_2022}")
    print(f"  Saldo (Zuzug - Wegzug): {z_2022 - w_2022}")
    print(f"  Gesamtmigration (Zuzug + Wegzug): {z_2022 + w_2022}")

# Данные за 2023
zuzug_2023_row = df[df['herkunftsgebiet_wegzugsgebiet'].str.contains('2023_ Zuzug', na=False)]
wegzug_2023_row = df[df['herkunftsgebiet_wegzugsgebiet'].str.contains('2023_ Wegzug', na=False)]

if not zuzug_2023_row.empty and not wegzug_2023_row.empty:
    zuzug_2023 = zuzug_2023_row[ukraine_col].iloc[0]
    wegzug_2023 = wegzug_2023_row[ukraine_col].iloc[0]
    
    z_2023 = float(str(zuzug_2023).replace(',', '.')) if pd.notna(zuzug_2023) else 0
    w_2023 = float(str(wegzug_2023).replace(',', '.')) if pd.notna(wegzug_2023) else 0
    
    print(f"\n2023:")
    print(f"  Zuzug: {z_2023}")
    print(f"  Wegzug: {w_2023}")
    print(f"  Saldo (Zuzug - Wegzug): {z_2023 - w_2023}")
    print(f"  Gesamtmigration (Zuzug + Wegzug): {z_2023 + w_2023}")

