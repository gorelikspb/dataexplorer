"""
Skript zum Herunterladen von Daten von Open Data Konstanz
https://offenedaten-konstanz.de/
"""

import requests
from pathlib import Path
import json
from bs4 import BeautifulSoup
import logging
from urllib.parse import urljoin, urlparse

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BASE_URL = "https://offenedaten-konstanz.de"
DATA_DIR = Path(__file__).parent.parent / "data" / "raw"


def get_datasets_from_portal():
    """
    Ruft Liste der Datensätze vom Open Data Portal ab
    """
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    })
    
    # CKAN API Endpoint
    api_url = f"{BASE_URL}/api/3/action/package_list"
    
    try:
        response = session.get(api_url, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        if data.get('success'):
            datasets = data.get('result', [])
            logger.info(f"Gefunden: {len(datasets)} Datensätze")
            return datasets
        else:
            logger.error(f"API Fehler: {data}")
            return []
    except Exception as e:
        logger.error(f"Fehler beim Abrufen der Datensätze: {e}")
        return []


def get_dataset_details(dataset_id):
    """
    Ruft Details zu einem Datensatz ab
    """
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    })
    
    api_url = f"{BASE_URL}/api/3/action/package_show"
    
    try:
        response = session.get(api_url, params={'id': dataset_id}, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        if data.get('success'):
            result = data.get('result')
            # Prüfe ob result ein Dict ist
            if isinstance(result, dict):
                return result
            else:
                logger.warning(f"Unerwartetes Format für {dataset_id}: {type(result)}")
                return None
        else:
            return None
    except Exception as e:
        logger.error(f"Fehler beim Abrufen von {dataset_id}: {e}")
        return None


def download_file(url, filename, data_dir):
    """
    Lädt eine Datei herunter
    """
    filepath = data_dir / filename
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    })
    
    try:
        logger.info(f"Lade herunter: {url}")
        response = session.get(url, timeout=30, stream=True)
        response.raise_for_status()
        
        with open(filepath, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        logger.info(f"Erfolgreich: {filepath}")
        return filepath
    except Exception as e:
        logger.error(f"Fehler beim Herunterladen von {url}: {e}")
        return None


def find_csv_excel_resources(dataset):
    """
    Findet CSV und Excel Ressourcen in einem Datensatz
    """
    resources = dataset.get('resources', [])
    csv_excel = []
    
    for resource in resources:
        format_type = resource.get('format', '').upper()
        url = resource.get('url', '')
        
        # Prüfe Format
        if format_type in ['CSV', 'XLS', 'XLSX', 'EXCEL']:
            csv_excel.append(resource)
        # Prüfe auch URL-Endung
        elif any(url.lower().endswith(ext) for ext in ['.csv', '.xls', '.xlsx']):
            csv_excel.append(resource)
    
    return csv_excel


def main():
    """
    Hauptfunktion: Lädt CSV/Excel Dateien von Open Data Konstanz herunter
    """
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    
    logger.info("Suche nach Datensätzen auf Open Data Konstanz...")
    datasets = get_datasets_from_portal()
    
    if not datasets:
        logger.warning("Keine Datensätze gefunden")
        return
    
    downloaded_files = []
    
    # Durchsuche Datensätze nach CSV/Excel
    for dataset_id in datasets[:20]:  # Begrenze auf erste 20 für Demo
        logger.info(f"Prüfe Datensatz: {dataset_id}")
        dataset = get_dataset_details(dataset_id)
        
        if not dataset:
            continue
        
        # Finde CSV/Excel Ressourcen
        resources = find_csv_excel_resources(dataset)
        
        if resources:
            logger.info(f"  Gefunden: {len(resources)} CSV/Excel Dateien")
            
            for resource in resources:
                if not isinstance(resource, dict):
                    continue
                    
                url = resource.get('url')
                name = resource.get('name', dataset_id)
                format_type = resource.get('format', '')
                
                # Erstelle Dateiname
                if url:
                    parsed_url = urlparse(url)
                    filename = Path(parsed_url.path).name
                    if not filename or filename == '/':
                        # Fallback: verwende name oder dataset_id
                        ext = '.csv' if format_type.upper() == 'CSV' else '.xlsx'
                        filename = f"{dataset_id}_{name}{ext}".replace(' ', '_').replace('/', '_')
                    
                    # Lade Datei herunter
                    filepath = download_file(url, filename, DATA_DIR)
                    if filepath:
                        dataset_title = dataset.get('title', dataset_id) if isinstance(dataset, dict) else dataset_id
                        downloaded_files.append({
                            'dataset_id': dataset_id,
                            'dataset_name': dataset_title,
                            'filename': filename,
                            'url': url,
                            'format': format_type
                        })
    
    # Speichere Metadaten
    metadata_file = DATA_DIR / 'download_metadata.json'
    with open(metadata_file, 'w', encoding='utf-8') as f:
        json.dump(downloaded_files, f, indent=2, ensure_ascii=False)
    
    logger.info(f"\nZusammenfassung:")
    logger.info(f"  Heruntergeladen: {len(downloaded_files)} Dateien")
    logger.info(f"  Speicherort: {DATA_DIR}")
    logger.info(f"  Metadaten: {metadata_file}")
    
    return downloaded_files


if __name__ == "__main__":
    main()

