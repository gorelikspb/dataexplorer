"""
Modul zum Herunterladen von Statistikdaten von der Website der Stadt Konstanz
"""

import requests
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime
import pandas as pd
from bs4 import BeautifulSoup
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BASE_URL = "https://www.konstanz.de/leben+in+konstanz/statistik"
DATA_DIR = Path(__file__).parent.parent / "data" / "raw"


class DataDownloader:
    """Klasse zum Herunterladen von Statistikdaten"""
    
    def __init__(self, base_url: str = BASE_URL, data_dir: Path = DATA_DIR):
        self.base_url = base_url
        self.data_dir = data_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def discover_datasets(self) -> List[Dict]:
        """
        Entdeckt verfügbare Datensätze auf der Website
        
        Returns:
            Liste von Dictionaries mit Metadaten zu jedem Datensatz
        """
        logger.info(f"Suche nach Datensätzen auf {self.base_url}")
        
        try:
            response = self.session.get(self.base_url, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')
            
            datasets = []
            # TODO: Implementiere Logik zum Finden von CSV/XLS Links
            # Dies hängt von der tatsächlichen Struktur der Website ab
            
            logger.info(f"Gefunden: {len(datasets)} Datensätze")
            return datasets
            
        except Exception as e:
            logger.error(f"Fehler beim Entdecken von Datensätzen: {e}")
            return []
    
    def download_file(self, url: str, filename: Optional[str] = None) -> Path:
        """
        Lädt eine Datei herunter
        
        Args:
            url: URL der Datei
            filename: Optionaler Dateiname (wird aus URL extrahiert wenn nicht angegeben)
            
        Returns:
            Pfad zur heruntergeladenen Datei
        """
        if filename is None:
            filename = url.split('/')[-1]
        
        filepath = self.data_dir / filename
        
        logger.info(f"Lade herunter: {url} -> {filepath}")
        
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            
            with open(filepath, 'wb') as f:
                f.write(response.content)
            
            logger.info(f"Erfolgreich heruntergeladen: {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"Fehler beim Herunterladen von {url}: {e}")
            raise
    
    def load_dataframe(self, filepath: Path) -> pd.DataFrame:
        """
        Lädt eine CSV oder Excel-Datei als DataFrame
        
        Args:
            filepath: Pfad zur Datei
            
        Returns:
            DataFrame mit den Daten
        """
        logger.info(f"Lade DataFrame aus {filepath}")
        
        if filepath.suffix.lower() == '.csv':
            # Versuche verschiedene Encodings
            for encoding in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    df = pd.read_csv(filepath, encoding=encoding)
                    logger.info(f"Erfolgreich geladen mit Encoding: {encoding}")
                    return df
                except UnicodeDecodeError:
                    continue
            raise ValueError(f"Konnte Datei nicht mit bekannten Encodings laden: {filepath}")
        
        elif filepath.suffix.lower() in ['.xls', '.xlsx']:
            df = pd.read_excel(filepath)
            logger.info(f"Erfolgreich geladen: {filepath}")
            return df
        
        else:
            raise ValueError(f"Nicht unterstütztes Dateiformat: {filepath.suffix}")
    
    def get_metadata(self, url: str, filepath: Path) -> Dict:
        """
        Erstellt Metadaten für einen Datensatz
        
        Args:
            url: URL der Quelle
            filepath: Pfad zur heruntergeladenen Datei
            
        Returns:
            Dictionary mit Metadaten
        """
        metadata = {
            'quelle': url,
            'heruntergeladen_am': datetime.now().isoformat(),
            'dateiname': filepath.name,
            'pfad': str(filepath),
            'format': filepath.suffix.lower(),
        }
        
        # Versuche, DataFrame zu laden um weitere Metadaten zu extrahieren
        try:
            df = self.load_dataframe(filepath)
            metadata.update({
                'anzahl_zeilen': len(df),
                'anzahl_spalten': len(df.columns),
                'spalten': list(df.columns),
            })
        except Exception as e:
            logger.warning(f"Konnte Metadaten nicht vollständig extrahieren: {e}")
        
        return metadata


def download_statistics() -> List[Dict]:
    """
    Hauptfunktion zum Herunterladen aller verfügbaren Statistikdaten
    
    Returns:
        Liste von Metadaten-Dictionaries für jeden heruntergeladenen Datensatz
    """
    downloader = DataDownloader()
    datasets = downloader.discover_datasets()
    
    downloaded = []
    for dataset in datasets:
        try:
            url = dataset.get('url')
            if url:
                filepath = downloader.download_file(url)
                metadata = downloader.get_metadata(url, filepath)
                metadata.update(dataset)  # Füge ursprüngliche Metadaten hinzu
                downloaded.append(metadata)
        except Exception as e:
            logger.error(f"Fehler beim Verarbeiten von {dataset}: {e}")
    
    return downloaded


if __name__ == "__main__":
    # Test
    datasets = download_statistics()
    print(f"Heruntergeladen: {len(datasets)} Datensätze")


