"""
Modul zum Export von bereinigten Daten und Metadaten
- CSV Export
- JSON/YAML Metadaten
"""

import pandas as pd
import json
import yaml
from pathlib import Path
from typing import Dict, Optional
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DataExporter:
    """Klasse zum Export von Daten und Metadaten"""
    
    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def export_dataframe(self,
                        df: pd.DataFrame,
                        filename: str,
                        format: str = 'csv') -> Path:
        """
        Exportiert DataFrame in verschiedene Formate
        
        Args:
            df: DataFrame zum Exportieren
            filename: Dateiname (ohne Extension)
            format: Format ('csv', 'excel', 'json')
            
        Returns:
            Pfad zur exportierten Datei
        """
        if format == 'csv':
            filepath = self.output_dir / f"{filename}.csv"
            df.to_csv(filepath, index=False, encoding='utf-8')
        elif format == 'excel':
            filepath = self.output_dir / f"{filename}.xlsx"
            df.to_excel(filepath, index=False)
        elif format == 'json':
            filepath = self.output_dir / f"{filename}.json"
            df.to_json(filepath, orient='records', indent=2, force_ascii=False)
        else:
            raise ValueError(f"Nicht unterstütztes Format: {format}")
        
        logger.info(f"DataFrame exportiert: {filepath}")
        return filepath
    
    def export_metadata(self,
                       metadata: Dict,
                       filename: str,
                       format: str = 'json') -> Path:
        """
        Exportiert Metadaten in JSON oder YAML
        
        Args:
            metadata: Dictionary mit Metadaten
            filename: Dateiname (ohne Extension)
            format: Format ('json' oder 'yaml')
            
        Returns:
            Pfad zur exportierten Datei
        """
        # Füge Timestamp hinzu
        metadata['exportiert_am'] = datetime.now().isoformat()
        
        if format == 'json':
            filepath = self.output_dir / f"{filename}.json"
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2, ensure_ascii=False)
        elif format == 'yaml':
            filepath = self.output_dir / f"{filename}.yaml"
            with open(filepath, 'w', encoding='utf-8') as f:
                yaml.dump(metadata, f, allow_unicode=True, default_flow_style=False)
        else:
            raise ValueError(f"Nicht unterstütztes Format: {format}")
        
        logger.info(f"Metadaten exportiert: {filepath}")
        return filepath
    
    def create_metadata(self,
                       df: pd.DataFrame,
                       source_url: str,
                       description: str = "",
                       theme: str = "") -> Dict:
        """
        Erstellt Metadaten-Dictionary für einen Datensatz
        
        Args:
            df: DataFrame
            source_url: URL der Quelle
            description: Beschreibung des Datensatzes
            theme: Themenbereich
            
        Returns:
            Dictionary mit Metadaten
        """
        metadata = {
            'quelle': source_url,
            'aktualisiert_am': datetime.now().isoformat(),
            'beschreibung': description,
            'themenbereich': theme,
            'anzahl_zeilen': len(df),
            'anzahl_spalten': len(df.columns),
            'spalten': {}
        }
        
        # Spalten-Metadaten
        for col in df.columns:
            metadata['spalten'][col] = {
                'datentyp': str(df[col].dtype),
                'fehlende_werte': int(df[col].isnull().sum()),
                'eindeutige_werte': int(df[col].nunique()),
            }
            
            # Zusätzliche Informationen für numerische Spalten
            if pd.api.types.is_numeric_dtype(df[col]):
                metadata['spalten'][col]['min'] = float(df[col].min()) if not df[col].isnull().all() else None
                metadata['spalten'][col]['max'] = float(df[col].max()) if not df[col].isnull().all() else None
                metadata['spalten'][col]['mittelwert'] = float(df[col].mean()) if not df[col].isnull().all() else None
        
        return metadata
    
    def export_dataset(self,
                      df: pd.DataFrame,
                      source_url: str,
                      dataset_name: str,
                      description: str = "",
                      theme: str = "",
                      export_formats: list = ['csv', 'json']) -> Dict[str, Path]:
        """
        Exportiert vollständigen Datensatz mit Metadaten
        
        Args:
            df: DataFrame
            source_url: URL der Quelle
            dataset_name: Name des Datensatzes
            description: Beschreibung
            theme: Themenbereich
            export_formats: Liste von Formaten für Datenexport
            
        Returns:
            Dictionary mit Pfaden zu exportierten Dateien
        """
        exported_files = {}
        
        # Exportiere Daten
        for fmt in export_formats:
            filepath = self.export_dataframe(df, dataset_name, fmt)
            exported_files[f'data_{fmt}'] = filepath
        
        # Erstelle und exportiere Metadaten
        metadata = self.create_metadata(df, source_url, description, theme)
        
        json_path = self.export_metadata(metadata, f"{dataset_name}_metadata", 'json')
        yaml_path = self.export_metadata(metadata, f"{dataset_name}_metadata", 'yaml')
        
        exported_files['metadata_json'] = json_path
        exported_files['metadata_yaml'] = yaml_path
        
        logger.info(f"Datensatz exportiert: {dataset_name}")
        return exported_files


def export_dataset(df: pd.DataFrame,
                   source_url: str,
                   dataset_name: str,
                   output_dir: Path,
                   description: str = "",
                   theme: str = "") -> Dict[str, Path]:
    """
    Hauptfunktion zum Export eines Datensatzes
    
    Args:
        df: DataFrame
        source_url: URL der Quelle
        dataset_name: Name des Datensatzes
        output_dir: Ausgabeverzeichnis
        description: Beschreibung
        theme: Themenbereich
        
    Returns:
        Dictionary mit Pfaden zu exportierten Dateien
    """
    exporter = DataExporter(output_dir)
    return exporter.export_dataset(
        df, source_url, dataset_name, description, theme
    )


if __name__ == "__main__":
    # Test
    test_data = pd.DataFrame({
        'jahr': [2020, 2021, 2022],
        'einwohner': [85000, 86000, 87000],
    })
    
    output_dir = Path("output/test")
    files = export_dataset(
        test_data,
        "https://example.com/data",
        "test_dataset",
        output_dir,
        "Test-Datensatz",
        "Statistik"
    )
    
    print("Exportierte Dateien:")
    for key, path in files.items():
        print(f"  {key}: {path}")


