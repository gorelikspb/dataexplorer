"""
Setup-Skript für das Projekt (optional)
"""

from setuptools import setup, find_packages

setup(
    name="konstanz-data-explorer",
    version="0.1.0",
    description="Prototyp eines Werkzeugs zur Analyse und Strukturierung offener Statistikdaten der Stadt Konstanz",
    author="",
    packages=find_packages(),
    install_requires=[
        "pandas>=2.0.0",
        "numpy>=1.24.0",
        "requests>=2.31.0",
        "openpyxl>=3.1.0",
        "python-dateutil>=2.8.0",
        "matplotlib>=3.7.0",
        "plotly>=5.17.0",
        "seaborn>=0.12.0",
        "streamlit>=1.28.0",
        "pyyaml>=6.0",
        "tqdm>=4.66.0",
        "beautifulsoup4>=4.12.0",
    ],
    python_requires=">=3.8",
)

