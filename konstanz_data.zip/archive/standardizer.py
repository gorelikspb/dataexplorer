"""
Modul zur Standardisierung von Statistikdaten
- Normalisiert Spaltennamen
- Standardisiert Datumsformate
- Identifiziert Probleme (Lücken, Formate)
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from datetime import datetime
import logging
import re

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DataStandardizer:
    """Klasse zur Standardisierung von Daten"""
    
    # Mapping von deutschen Monatsnamen zu Zahlen
    MONTH_MAPPING = {
        'januar': '01', 'jan': '01',
        'februar': '02', 'feb': '02',
        'märz': '03', 'mär': '03', 'marz': '03', 'mar': '03',
        'april': '04', 'apr': '04',
        'mai': '05', 'may': '05',
        'juni': '06', 'jun': '06',
        'juli': '07', 'jul': '07',
        'august': '08', 'aug': '08',
        'september': '09', 'sep': '09', 'sept': '09',
        'oktober': '10', 'okt': '10', 'oct': '10',
        'november': '11', 'nov': '11',
        'dezember': '12', 'dez': '12', 'dec': '12'
    }
    
    def __init__(self):
        self.column_mapping = {}
        self.problems = []
    
    def standardize_column_names(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Standardisiert Spaltennamen
        
        Args:
            df: DataFrame mit originalen Spaltennamen
            
        Returns:
            DataFrame mit standardisierten Spaltennamen
        """
        df = df.copy()
        
        # Erstelle Mapping für Spaltennamen
        standardized_names = {}
        for col in df.columns:
            standardized = self._normalize_column_name(col)
            standardized_names[col] = standardized
        
        # Wende Mapping an
        df.rename(columns=standardized_names, inplace=True)
        self.column_mapping = standardized_names
        
        logger.info(f"Spaltennamen standardisiert: {standardized_names}")
        return df
    
    def _normalize_column_name(self, name: str) -> str:
        """
        Normalisiert einen einzelnen Spaltennamen
        
        Args:
            name: Originaler Spaltenname
            
        Returns:
            Normalisierter Spaltenname
        """
        # Entferne Leerzeichen am Anfang/Ende
        name = name.strip()
        
        # Ersetze Leerzeichen durch Unterstriche
        name = re.sub(r'\s+', '_', name)
        
        # Konvertiere zu Kleinbuchstaben
        name = name.lower()
        
        # Entferne Sonderzeichen (behalte nur Buchstaben, Zahlen, Unterstriche)
        name = re.sub(r'[^a-z0-9_]', '', name)
        
        # Entferne führende/abschließende Unterstriche
        name = name.strip('_')
        
        # Häufige deutsche Begriffe übersetzen
        translations = {
            'jahr': 'jahr',
            'monat': 'monat',
            'datum': 'datum',
            'einwohner': 'einwohner',
            'bevölkerung': 'bevoelkerung',
            'alter': 'alter',
            'geschlecht': 'geschlecht',
            'stadtteil': 'stadtteil',
            'wohnung': 'wohnung',
            'verkehr': 'verkehr',
        }
        
        for de, en in translations.items():
            if de in name:
                name = name.replace(de, en)
        
        return name
    
    def standardize_dates(self, df: pd.DataFrame, date_columns: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Standardisiert Datumsspalten
        
        Args:
            df: DataFrame
            date_columns: Liste von Spaltennamen, die Daten enthalten (wird automatisch erkannt wenn None)
            
        Returns:
            DataFrame mit standardisierten Datumsformaten
        """
        df = df.copy()
        
        if date_columns is None:
            date_columns = self._detect_date_columns(df)
        
        for col in date_columns:
            if col in df.columns:
                df[col] = df[col].apply(self._normalize_date)
        
        logger.info(f"Datumsspalten standardisiert: {date_columns}")
        return df
    
    def _detect_date_columns(self, df: pd.DataFrame) -> List[str]:
        """Erkennt Spalten, die wahrscheinlich Daten enthalten"""
        date_columns = []
        
        for col in df.columns:
            col_lower = col.lower()
            if any(keyword in col_lower for keyword in ['datum', 'date', 'jahr', 'jahr', 'monat', 'month']):
                date_columns.append(col)
            elif df[col].dtype == 'object':
                # Versuche, einige Werte zu parsen
                sample = df[col].dropna().head(10)
                if len(sample) > 0:
                    try:
                        pd.to_datetime(sample.iloc[0], errors='raise')
                        date_columns.append(col)
                    except:
                        pass
        
        return date_columns
    
    def _normalize_date(self, value) -> Optional[str]:
        """
        Normalisiert ein einzelnes Datum
        
        Args:
            value: Datumswert (verschiedene Formate möglich)
            
        Returns:
            Normalisiertes Datum im Format YYYY-MM-DD oder None
        """
        if pd.isna(value):
            return None
        
        # Wenn bereits datetime
        if isinstance(value, (pd.Timestamp, datetime)):
            return value.strftime('%Y-%m-%d')
        
        # Wenn String
        if isinstance(value, str):
            value = value.strip().lower()
            
            # Versuche verschiedene Formate
            formats = [
                '%Y-%m-%d',
                '%d.%m.%Y',
                '%d/%m/%Y',
                '%Y-%m',
                '%m/%Y',
                '%Y',
            ]
            
            for fmt in formats:
                try:
                    dt = datetime.strptime(value, fmt)
                    return dt.strftime('%Y-%m-%d')
                except:
                    pass
            
            # Versuche deutsche Monatsnamen
            for month_name, month_num in self.MONTH_MAPPING.items():
                if month_name in value:
                    # Extrahiere Jahr
                    year_match = re.search(r'\d{4}', value)
                    if year_match:
                        year = year_match.group()
                        return f"{year}-{month_num}-01"
        
        return None
    
    def detect_problems(self, df: pd.DataFrame) -> Dict:
        """
        Erkennt Probleme in den Daten
        
        Args:
            df: DataFrame
            
        Returns:
            Dictionary mit gefundenen Problemen
        """
        problems = {
            'fehlende_werte': {},
            'duplikate': 0,
            'datentypen': {},
            'leere_spalten': [],
        }
        
        # Fehlende Werte
        missing = df.isnull().sum()
        for col in df.columns:
            if missing[col] > 0:
                problems['fehlende_werte'][col] = {
                    'anzahl': int(missing[col]),
                    'prozent': float(missing[col] / len(df) * 100)
                }
        
        # Duplikate
        problems['duplikate'] = int(df.duplicated().sum())
        
        # Datentypen
        for col in df.columns:
            problems['datentypen'][col] = str(df[col].dtype)
        
        # Leere Spalten
        problems['leere_spalten'] = [col for col in df.columns if df[col].isnull().all()]
        
        self.problems = problems
        logger.info(f"Probleme erkannt: {problems}")
        return problems
    
    def standardize(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Führt alle Standardisierungsschritte durch
        
        Args:
            df: Original DataFrame
            
        Returns:
            Standardisierter DataFrame
        """
        logger.info("Starte Standardisierung...")
        
        # 1. Spaltennamen standardisieren
        df = self.standardize_column_names(df)
        
        # 2. Daten standardisieren
        df = self.standardize_dates(df)
        
        # 3. Probleme erkennen
        problems = self.detect_problems(df)
        
        logger.info("Standardisierung abgeschlossen")
        return df


def standardize_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Hauptfunktion zur Standardisierung von Daten
    
    Args:
        df: Original DataFrame
        
    Returns:
        Standardisierter DataFrame
    """
    standardizer = DataStandardizer()
    return standardizer.standardize(df)


if __name__ == "__main__":
    # Test
    test_data = pd.DataFrame({
        'Jahr': [2020, 2021, 2022],
        'Einwohner': [85000, 86000, None],
        'Datum': ['01.01.2020', '2021-01-01', 'Januar 2022']
    })
    
    standardizer = DataStandardizer()
    standardized = standardizer.standardize(test_data)
    print(standardized)
    print("\nProbleme:")
    print(standardizer.problems)

