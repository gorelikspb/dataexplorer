# PowerShell скрипт для запуска Streamlit приложения
& .\venv\Scripts\Activate.ps1
streamlit run app.py

