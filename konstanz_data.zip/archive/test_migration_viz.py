"""
Тестирование визуализации данных миграции
"""

import pandas as pd
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))

from src.visualizer import DataVisualizer
import plotly.graph_objects as go
import plotly.express as px

# Загрузи файл
file_path = Path("data/raw/Aussenwanderung_nach_Herkunfts_Ziel-Staat_2010-2023_0_0.csv")
df = pd.read_csv(file_path, sep=';', encoding='utf-8')

print(f"Shape: {df.shape}")
print("\nFirst rows:")
print(df.head())
print("\nColumns (first 10):")
print(df.columns.tolist()[:10])

# Изучи структуру
print("\nFirst column (key):")
print(df.iloc[:, 0].head(20))

