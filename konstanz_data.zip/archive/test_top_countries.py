import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from src.visualizer import DataVisualizer
import pandas as pd

df = pd.read_csv('data/raw/Aussenwanderung_nach_Herkunfts_Ziel-Staat_2010-2023_0_0.csv', sep=';', encoding='utf-8')
viz = DataVisualizer(df)
figs = viz.plot_migration_data()

print(f'Created {len(figs)} figures')
if len(figs) > 2:
    if len(figs[2].data) > 0:
        trace = figs[2].data[0]
        print(f'Top 10 countries chart has data')
        print('Y (countries) type:', type(trace.y))
        print('X (values) type:', type(trace.x))
        if hasattr(trace.y, '__len__'):
            print('Countries count:', len(trace.y))
            print('First 5 countries:', list(trace.y)[:5] if hasattr(trace.y, '__iter__') else trace.y[:5])
        if hasattr(trace.x, '__len__'):
            print('Values count:', len(trace.x))
            print('First 5 values:', list(trace.x)[:5] if hasattr(trace.x, '__iter__') else trace.x[:5])
    else:
        print('No data in top 10 chart')

