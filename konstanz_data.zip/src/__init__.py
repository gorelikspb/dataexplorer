"""
Konstanz Open Data Explorer
Prototyp eines Werkzeugs zur Analyse und Strukturierung offener Statistikdaten der Stadt Konstanz
"""

__version__ = "0.1.0"


